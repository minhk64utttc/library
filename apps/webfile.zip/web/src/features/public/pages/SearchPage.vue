<script setup lang="ts">
import { computed, onMounted, reactive, ref, watch } from 'vue';
import { RouterLink, useRoute, useRouter } from 'vue-router';
import type { Paginated, PublicRecordDto } from '@thu-vien/shared';
import { searchRecords } from '../api';

const route = useRoute();
const router = useRouter();
const loading = ref(false);
const error = ref('');
const results = ref<Paginated<PublicRecordDto> | null>(null);
const form = reactive({ q: '', subject: '', author: '', language: '', yearFrom: '', yearTo: '', sort: 'newest' });
const totalPages = computed(() => Math.max(1, Math.ceil((results.value?.total ?? 0) / (results.value?.pageSize ?? 20))));

function routeParams(page = 1) {
  return Object.fromEntries(Object.entries({
    q: form.q.trim(), subject: form.subject.trim(), author: form.author.trim(), language: form.language.trim(),
    yearFrom: form.yearFrom, yearTo: form.yearTo, sort: form.sort, page: String(page),
  }).filter(([, value]) => value !== ''));
}

async function loadFromUrl(): Promise<void> {
  const query = route.query;
  form.q = typeof query.q === 'string' ? query.q : '';
  form.subject = typeof query.subject === 'string' ? query.subject : '';
  form.author = typeof query.author === 'string' ? query.author : '';
  form.language = typeof query.language === 'string' ? query.language : '';
  form.yearFrom = typeof query.yearFrom === 'string' ? query.yearFrom : '';
  form.yearTo = typeof query.yearTo === 'string' ? query.yearTo : '';
  form.sort = query.sort === 'title' ? 'title' : 'newest';
  const page = Math.max(1, Number(query.page) || 1);
  loading.value = true;
  error.value = '';
  try {
    results.value = await searchRecords({
      ...Object.fromEntries(Object.entries({ q: form.q, subject: form.subject, author: form.author, language: form.language })
        .filter(([, value]) => Boolean(value))),
      ...(form.yearFrom ? { yearFrom: Number(form.yearFrom) } : {}),
      ...(form.yearTo ? { yearTo: Number(form.yearTo) } : {}),
      page, pageSize: 20, sort: form.sort as 'newest' | 'title',
    });
  } catch {
    error.value = 'Không tải được danh mục. Vui lòng thử lại.';
  } finally {
    loading.value = false;
  }
}

function submitSearch(): void {
  if (form.yearFrom && form.yearTo && Number(form.yearFrom) > Number(form.yearTo)) {
    error.value = 'Năm bắt đầu phải nhỏ hơn hoặc bằng năm kết thúc.';
    return;
  }
  void router.push({ name: 'public-search', query: routeParams() });
}

function changePage(page: number): void {
  void router.push({ name: 'public-search', query: routeParams(page) });
}

function availability(record: PublicRecordDto): number {
  return record.editions.reduce((sum, edition) => sum + edition.availableCount, 0);
}

watch(() => route.fullPath, () => void loadFromUrl());
onMounted(() => void loadFromUrl());
</script>

<template>
  <section class="public-search">
    <header class="public-search__intro">
      <p class="eyebrow">Khám phá tri thức</p>
      <h1>Tra cứu tài liệu thư viện</h1>
      <p>Tìm sách và tài liệu theo nhan đề, tác giả, chủ đề hoặc thông tin xuất bản.</p>
    </header>

    <form class="public-search__filters" role="search" @submit.prevent="submitSearch">
      <label class="public-search__keyword">Từ khóa
        <input v-model="form.q" type="search" placeholder="Tên sách, tác giả…" />
      </label>
      <label>Chủ đề<input v-model="form.subject" type="search" /></label>
      <label>Tác giả<input v-model="form.author" type="search" /></label>
      <label>Ngôn ngữ<input v-model="form.language" type="search" placeholder="Ví dụ: Tiếng Việt" /></label>
      <label>Từ năm<input v-model="form.yearFrom" type="number" min="0" max="3000" inputmode="numeric" /></label>
      <label>Đến năm<input v-model="form.yearTo" type="number" min="0" max="3000" inputmode="numeric" /></label>
      <label>Sắp xếp<select v-model="form.sort"><option value="newest">Mới cập nhật</option><option value="title">Tên A–Z</option></select></label>
      <button type="submit">Tìm tài liệu</button>
    </form>

    <p v-if="error" role="alert">{{ error }}</p>
    <div v-if="loading" class="empty-state" role="status">Đang tải danh mục…</div>
    <template v-else-if="results">
      <p class="public-search__count">{{ results.total }} tài liệu phù hợp</p>
      <div v-if="results.items.length" class="public-search__grid">
        <article v-for="record in results.items" :key="record.id" class="public-book-card">
          <span class="public-book-card__mark" aria-hidden="true">▤</span>
          <div class="public-book-card__body">
            <h2><RouterLink :to="`/books/${record.id}`">{{ record.title }}</RouterLink></h2>
            <p>{{ record.author || 'Chưa cập nhật tác giả' }}</p>
            <dl>
              <div v-if="record.subject"><dt>Chủ đề</dt><dd>{{ record.subject }}</dd></div>
              <div v-if="record.classification"><dt>Ký hiệu</dt><dd>{{ record.classification }}</dd></div>
            </dl>
            <span class="status-badge" :data-state="availability(record) ? 'available' : 'reserved'">
              {{ availability(record) ? `${availability(record)} bản sẵn sàng` : 'Hiện không có bản sẵn sàng' }}
            </span>
          </div>
        </article>
      </div>
      <div v-else class="empty-state">Không tìm thấy tài liệu phù hợp. Hãy thử bỏ bớt điều kiện lọc.</div>
      <nav v-if="totalPages > 1" class="public-search__pagination" aria-label="Phân trang kết quả">
        <button type="button" :disabled="results.page <= 1" @click="changePage(results.page - 1)">Trang trước</button>
        <span>Trang {{ results.page }} / {{ totalPages }}</span>
        <button type="button" :disabled="results.page >= totalPages" @click="changePage(results.page + 1)">Trang sau</button>
      </nav>
    </template>
  </section>
</template>

<style scoped>
.public-search__intro { padding: 24px 28px; background: linear-gradient(110deg, #f7f9fd, #edf3fc); border-left: 4px solid var(--gold); border-radius: 12px; }
.public-search__intro h1 { margin: 8px 0; }
.public-search__intro p:last-child { margin-bottom: 0; color: var(--muted); }
.public-search__filters { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); align-items: end; gap: 14px; margin: 22px 0; padding: 20px; background: #fbfcff; border: 1px solid var(--line); border-radius: 12px; }
.public-search__keyword { grid-column: span 2; }
.public-search__filters button { min-height: 42px; }
.public-search__count { color: var(--muted); font-size: .86rem; }
.public-search__grid { display: grid; gap: 12px; }
.public-book-card { display: flex; gap: 17px; padding: 20px; background: #fff; border: 1px solid var(--line); border-radius: 12px; box-shadow: 0 5px 18px #243b7308; }
.public-book-card__mark { display: grid; place-items: center; width: 44px; height: 56px; flex: 0 0 auto; color: var(--navy); background: #edf2fa; border: 1px solid #d8e1ef; border-radius: 5px 9px 9px 5px; font-size: 1.4rem; }
.public-book-card__body { min-width: 0; }
.public-book-card h2 { margin: 0 0 5px; font-size: 1.05rem; }
.public-book-card h2 a { text-decoration: none; }
.public-book-card h2 a:hover { text-decoration: underline; text-underline-offset: 3px; }
.public-book-card p { margin: 0 0 10px; color: var(--muted); font-size: .86rem; }
.public-book-card dl { display: flex; flex-wrap: wrap; gap: 8px 22px; margin: 0 0 12px; font-size: .78rem; }
.public-book-card dl div { display: flex; gap: 6px; }
.public-book-card dt { color: var(--muted); }
.public-book-card dd { margin: 0; color: var(--ink); }
.public-search__pagination { display: flex; justify-content: center; align-items: center; gap: 16px; margin: 24px 0 4px; color: var(--muted); font-size: .85rem; }
@media (max-width: 760px) { .public-search__filters { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
@media (max-width: 480px) { .public-search__filters { grid-template-columns: 1fr; } .public-search__keyword { grid-column: auto; } .public-book-card { padding: 15px; } }
</style>
