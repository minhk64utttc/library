<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue';
import type { CatalogRecordDto, CopyDto, CopyStatus, LocationDto } from '@thu-vien/shared';

import { useSessionStore } from '@/features/auth/session.store';
import { ApiError } from '@/shared/api/client';
import * as catalogApi from '@/features/catalog/api';
import * as holdingsApi from '../api';
import { COPY_STATUS_OPTIONS, copyStatusLabel } from '../status';

const session = useSessionStore();
const canManage = computed(() => session.can('holdings:manage'));
const canEditCatalog = computed(() => session.can('catalog:write'));

const locations = ref<LocationDto[]>([]);
const copies = ref<CopyDto[]>([]);
const records = ref<CatalogRecordDto[]>([]);
const loading = ref(false);
const errorMessage = ref('');
const statusFilter = ref<CopyStatus | ''>('');
const pendingId = ref<string | null>(null);
const submitting = ref(false);

const locationForm = reactive({ code: '', name: '' });
const copyForm = reactive({ editionId: '', count: 1, locationId: '' });
const callNumberForm = reactive({ editionId: '', callNumber: '' });

const editionOptions = computed(() =>
  records.value.filter((record) => record.status === 'published').flatMap((record) =>
    record.editions.map((edition) => ({
      id: edition.id,
      recordId: record.id,
      callNumber: edition.callNumber,
      label: `${record.title} — lần ${edition.editionNo ?? '?'}${edition.isbn ? ` · ${edition.isbn}` : ''}`,
    })),
  ),
);

async function onSetCallNumber(): Promise<void> {
  const edition = editionOptions.value.find((option) => option.id === callNumberForm.editionId);
  if (!edition) {
    errorMessage.value = 'Chọn ấn bản đã công bố.';
    return;
  }
  submitting.value = true;
  errorMessage.value = '';
  try {
    await catalogApi.setCallNumber(edition.recordId, edition.id, {
      callNumber: callNumberForm.callNumber.trim(),
    });
    callNumberForm.callNumber = '';
    await load();
  } catch {
    errorMessage.value = 'Không cập nhật được mã xếp giá.';
  } finally {
    submitting.value = false;
  }
}

async function load(): Promise<void> {
  loading.value = true;
  errorMessage.value = '';
  try {
    const [locationResult, copyResult, recordResult] = await Promise.all([
      holdingsApi.listLocations({ pageSize: 100 }),
      holdingsApi.listCopies({
        pageSize: 100,
        ...(statusFilter.value ? { status: statusFilter.value } : {}),
      }),
      holdingsApi.listRecordsForPicker(),
    ]);
    locations.value = locationResult.items;
    copies.value = copyResult.items;
    records.value = recordResult.items;
  } catch {
    errorMessage.value = 'Không tải được dữ liệu kho.';
  } finally {
    loading.value = false;
  }
}

async function onCreateLocation(): Promise<void> {
  submitting.value = true;
  errorMessage.value = '';
  try {
    await holdingsApi.createLocation({
      code: locationForm.code.trim(),
      name: locationForm.name.trim(),
    });
    locationForm.code = '';
    locationForm.name = '';
    await load();
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError && error.status === 409
        ? 'Mã vị trí đã tồn tại.'
        : 'Không tạo được vị trí.';
  } finally {
    submitting.value = false;
  }
}

async function onCreateCopies(): Promise<void> {
  if (!copyForm.editionId) {
    errorMessage.value = 'Chọn ấn bản trước khi thêm bản sao.';
    return;
  }
  submitting.value = true;
  errorMessage.value = '';
  try {
    await holdingsApi.createCopies({
      editionId: copyForm.editionId,
      count: Number(copyForm.count) || 1,
      ...(copyForm.locationId ? { locationId: copyForm.locationId } : {}),
    });
    await load();
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError && error.status === 409
        ? 'Mã cuốn bị trùng — đặt mã xếp giá riêng cho ấn bản.'
        : 'Không thêm được bản sao.';
  } finally {
    submitting.value = false;
  }
}

async function onUpdateCopy(copy: CopyDto, patch: { status?: CopyStatus; locationId?: string | null }): Promise<void> {
  pendingId.value = copy.id;
  errorMessage.value = '';
  try {
    await holdingsApi.updateCopy(copy.id, patch);
    await load();
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError && error.status === 400
        ? 'Chỉ đưa bản sao đang xử lý vào phục vụ khi bản ghi đã công bố, có mã xếp giá và vị trí.'
        : 'Không cập nhật được bản sao.';
  } finally {
    pendingId.value = null;
  }
}

function onActivate(copy: CopyDto): void {
  void onUpdateCopy(copy, { status: 'available' });
}

function onLocationChange(copy: CopyDto, event: Event): void {
  const value = (event.target as HTMLSelectElement).value;
  void onUpdateCopy(copy, { locationId: value || null });
}

onMounted(() => {
  void load();
});
</script>

<template>
  <section class="holdings">
    <h1>Bản sao &amp; kho</h1>

    <p v-if="errorMessage" role="alert">{{ errorMessage }}</p>
    <p v-if="loading">Đang tải…</p>

    <fieldset v-if="canManage">
      <legend>Thêm vị trí</legend>
      <form class="holdings__inline" @submit.prevent="onCreateLocation">
        <label>
          Mã vị trí
          <input v-model="locationForm.code" type="text" required maxlength="50" />
        </label>
        <label>
          Tên
          <input v-model="locationForm.name" type="text" required maxlength="200" />
        </label>
        <button type="submit" :disabled="submitting">Thêm vị trí</button>
      </form>
    </fieldset>

    <h2>Vị trí</h2>
    <p v-if="locations.length === 0" class="empty-state">Chưa có vị trí nào. Thêm vị trí để sắp xếp bản sao.</p>
    <table v-else>
      <thead>
        <tr>
          <th scope="col">Mã</th>
          <th scope="col">Tên</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="location in locations" :key="location.id">
          <td>{{ location.code }}</td>
          <td>{{ location.name }}</td>
        </tr>
      </tbody>
    </table>

    <fieldset v-if="canManage">
      <legend>Thêm bản sao</legend>
      <form class="holdings__inline" @submit.prevent="onCreateCopies">
        <label>
          Ấn bản
          <select v-model="copyForm.editionId" required>
            <option value="">—</option>
            <option v-for="option in editionOptions" :key="option.id" :value="option.id">
              {{ option.label }}
            </option>
          </select>
        </label>
        <label>
          Số lượng
          <input v-model.number="copyForm.count" type="number" min="1" max="50" required />
        </label>
        <label>
          Vị trí
          <select v-model="copyForm.locationId">
            <option value="">—</option>
            <option v-for="location in locations" :key="location.id" :value="location.id">
              {{ location.name }}
            </option>
          </select>
        </label>
        <button type="submit" :disabled="submitting">Thêm bản sao</button>
      </form>
    </fieldset>

    <fieldset v-if="canEditCatalog">
      <legend>Mã xếp giá cho ấn bản đã công bố</legend>
      <form class="holdings__inline" @submit.prevent="onSetCallNumber">
        <label>
          Ấn bản
          <select v-model="callNumberForm.editionId" name="editionId" required>
            <option value="">—</option>
            <option v-for="option in editionOptions" :key="option.id" :value="option.id">
              {{ option.label }}{{ option.callNumber ? ` · ${option.callNumber}` : '' }}
            </option>
          </select>
        </label>
        <label>
          Mã xếp giá
          <input v-model="callNumberForm.callNumber" type="text" name="callNumber" autocomplete="off" required maxlength="100" />
        </label>
        <button type="submit" :disabled="submitting">Lưu mã xếp giá</button>
      </form>
    </fieldset>

    <h2>Bản sao</h2>
    <label>
      Trạng thái
      <select v-model="statusFilter" @change="load">
        <option value="">Tất cả</option>
        <option v-for="status in COPY_STATUS_OPTIONS" :key="status" :value="status">
          {{ copyStatusLabel(status) }}
        </option>
      </select>
    </label>

    <p v-if="copies.length === 0" class="empty-state">Chưa có bản sao nào trong bộ lọc hiện tại.</p>
    <table v-else>
      <thead>
        <tr>
          <th scope="col">Mã cuốn</th>
          <th scope="col">Tác phẩm</th>
          <th scope="col">Trạng thái</th>
          <th scope="col">Vị trí</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="copy in copies" :key="copy.id">
          <td>{{ copy.code }}</td>
          <td>{{ copy.workTitle ?? '' }}</td>
          <td>
            <span class="status-badge" :data-state="copy.status">{{ copyStatusLabel(copy.status) }}</span>
            <button
              v-if="canManage && copy.status === 'processing'"
              type="button"
              :disabled="pendingId === copy.id || !copy.locationId"
              @click="onActivate(copy)"
            >
              Đưa vào phục vụ
            </button>
          </td>
          <td>
            <select
              v-if="canManage"
              :value="copy.locationId ?? ''"
              :disabled="pendingId === copy.id"
              @change="onLocationChange(copy, $event)"
            >
              <option value="">—</option>
              <option v-for="location in locations" :key="location.id" :value="location.id">
                {{ location.name }}
              </option>
            </select>
            <template v-else>{{ copy.locationId ?? '' }}</template>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>
