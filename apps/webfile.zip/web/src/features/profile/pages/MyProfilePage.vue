<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue';
import type { MyProfileDto, Role } from '@thu-vien/shared';
import { ApiError } from '@/shared/api/client';
import { loadMyProfile, removeMyProfilePhoto, saveMyProfile, uploadMyProfilePhoto } from '../api';

const profile = ref<MyProfileDto | null>(null);
const form = reactive({ fullName: '', phone: '', contactEmail: '', reminderEmailEnabled: true });
const loading = ref(true);
const saving = ref(false);
const error = ref('');
const notice = ref('');
const photoBusy = ref(false);
const photoError = ref('');
const photoNotice = ref('');

const roleLabels: Record<Role, string> = {
  reader: 'Bạn đọc', circulation: 'Cán bộ mượn trả', cataloging: 'Cán bộ biên mục',
  inventory: 'Cán bộ kiểm kê', digital: 'Cán bộ tài liệu số', manager: 'Quản lý thư viện', admin: 'Quản trị hệ thống',
};

async function load(): Promise<void> {
  loading.value = true;
  error.value = '';
  try {
    profile.value = await loadMyProfile();
    form.fullName = profile.value.fullName;
    form.phone = profile.value.phone ?? '';
    form.contactEmail = profile.value.contactEmail ?? '';
    form.reminderEmailEnabled = profile.value.reminderEmailEnabled;
  } catch {
    error.value = 'Không tải được hồ sơ. Hãy tải lại trang để thử lại.';
  } finally {
    loading.value = false;
  }
}

async function submit(): Promise<void> {
  if (saving.value) return;
  saving.value = true;
  error.value = '';
  notice.value = '';
  try {
    profile.value = await saveMyProfile({
      fullName: form.fullName,
      phone: form.phone,
      contactEmail: form.contactEmail,
      reminderEmailEnabled: form.reminderEmailEnabled,
    });
    notice.value = 'Thông tin liên hệ đã được lưu.';
  } catch (cause) {
    error.value = cause instanceof ApiError && cause.status === 400
      ? 'Tên, số điện thoại hoặc email liên hệ chưa đúng định dạng.'
      : 'Không lưu được hồ sơ. Thông tin của bạn vẫn được giữ trên biểu mẫu để thử lại.';
  } finally {
    saving.value = false;
  }
}

async function changePhoto(event: Event): Promise<void> {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  input.value = '';
  if (!file || photoBusy.value) return;
  photoError.value = '';
  photoNotice.value = '';
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    photoError.value = 'Chọn ảnh JPEG, PNG hoặc WebP.';
    return;
  }
  if (file.size > 5 * 1024 * 1024) {
    photoError.value = 'Ảnh phải nhỏ hơn 5 MB.';
    return;
  }
  photoBusy.value = true;
  try {
    profile.value = await uploadMyProfilePhoto(file);
    photoNotice.value = 'Ảnh hồ sơ đã được cập nhật.';
  } catch (cause) {
    photoError.value = cause instanceof ApiError && cause.status === 400
      ? cause.message
      : 'Không lưu được ảnh. Ảnh hiện tại vẫn được giữ nguyên.';
  } finally {
    photoBusy.value = false;
  }
}

async function removePhoto(): Promise<void> {
  if (photoBusy.value || !profile.value?.photoUrl || !window.confirm('Xóa ảnh hồ sơ hiện tại?')) return;
  photoBusy.value = true;
  photoError.value = '';
  photoNotice.value = '';
  try {
    profile.value = await removeMyProfilePhoto();
    photoNotice.value = 'Đã xóa ảnh hồ sơ.';
  } catch {
    photoError.value = 'Không xóa được ảnh hồ sơ. Vui lòng thử lại.';
  } finally {
    photoBusy.value = false;
  }
}

onMounted(() => void load());
</script>

<template>
  <section class="reader-profile" aria-labelledby="profile-title">
    <div class="reader-profile__heading">
      <p class="eyebrow">Khu vực bạn đọc</p>
      <h1 id="profile-title">Hồ sơ cá nhân</h1>
      <p>Cập nhật thông tin để thư viện liên hệ khi cần.</p>
    </div>

    <div v-if="loading" class="empty-state" role="status">Đang tải hồ sơ…</div>
    <p v-else-if="error && !profile" role="alert">{{ error }}</p>
    <div v-else-if="profile" class="reader-profile__folio">
      <aside class="reader-profile__identity" aria-label="Thông tin tài khoản">
        <img v-if="profile.photoUrl" class="reader-profile__photo" :src="profile.photoUrl" alt="Ảnh hồ sơ bạn đọc" />
        <span v-else class="reader-profile__seal" aria-hidden="true">{{ form.fullName.trim().charAt(0).toLocaleUpperCase('vi-VN') || 'T' }}</span>
        <div class="reader-profile__photo-tools">
          <label class="reader-profile__photo-picker" :class="{ 'reader-profile__photo-picker--busy': photoBusy }">
            {{ photoBusy ? 'Đang xử lý ảnh…' : profile.photoUrl ? 'Đổi ảnh hồ sơ' : 'Thêm ảnh hồ sơ' }}
            <input type="file" accept="image/jpeg,image/png,image/webp" :disabled="photoBusy" @change="changePhoto" />
          </label>
          <button v-if="profile.photoUrl" class="reader-profile__photo-remove" type="button" :disabled="photoBusy" @click="removePhoto">Xóa ảnh</button>
          <small>JPEG, PNG hoặc WebP · tối đa 5 MB</small>
          <p v-if="photoError" class="reader-profile__photo-error" role="alert">{{ photoError }}</p>
          <p v-if="photoNotice" class="reader-profile__photo-success" role="status">{{ photoNotice }}</p>
        </div>
        <span class="reader-profile__overline">Hồ sơ bạn đọc</span>
        <h2>{{ form.fullName || 'Chưa cập nhật họ tên' }}</h2>
        <p class="reader-profile__login-email">{{ profile.email }}</p>
        <div class="reader-profile__rule"></div>
        <span class="reader-profile__overline">Quyền tài khoản</span>
        <ul class="reader-profile__roles">
          <li v-for="role in profile.roles" :key="role">{{ roleLabels[role] }}</li>
        </ul>
        <div v-if="profile.libraryCard" class="reader-profile__card">
          <span class="reader-profile__overline">Thẻ thư viện</span>
          <strong>{{ profile.libraryCard.cardNumber }}</strong>
          <span>{{ profile.libraryCard.status === 'active' ? 'Đang hiệu lực' : profile.libraryCard.status === 'locked' ? 'Đang khóa' : 'Đã hết hạn' }}</span>
          <span>Hết hạn {{ new Date(`${profile.libraryCard.expiresOn}T12:00:00`).toLocaleDateString('vi-VN') }}</span>
        </div>
        <p class="reader-profile__footnote">Email đăng nhập và quyền truy cập do thư viện quản lý.</p>
      </aside>

      <div class="reader-profile__form-wrap">
        <div class="reader-profile__form-heading">
          <h2>Thông tin liên hệ</h2>
          <p>Email liên hệ có thể khác email dùng để đăng nhập.</p>
        </div>
        <p v-if="notice" class="reader-profile__success" role="status">{{ notice }}</p>
        <p v-if="error" role="alert">{{ error }}</p>
        <form @submit.prevent="submit">
          <label>Họ và tên
            <input v-model="form.fullName" name="fullName" autocomplete="name" required maxlength="200" />
          </label>
          <label>Email đăng nhập
            <input :value="profile.email" type="email" disabled aria-describedby="login-email-help" />
            <small id="login-email-help">Muốn đổi email đăng nhập, vui lòng liên hệ thư viện.</small>
          </label>
          <label>Email liên hệ
            <input v-model="form.contactEmail" name="contactEmail" type="email" autocomplete="email" maxlength="254" placeholder="Địa chỉ nhận thông tin từ thư viện" />
          </label>
          <label>Số điện thoại
            <input v-model="form.phone" name="phone" type="tel" autocomplete="tel" maxlength="20" placeholder="Ví dụ: 09xx xxx xxx" />
          </label>
          <button type="submit" :disabled="saving">{{ saving ? 'Đang lưu…' : 'Lưu thông tin' }}</button>
          <label class="reader-profile__email-preference"><input v-model="form.reminderEmailEnabled" name="reminderEmailEnabled" type="checkbox" /> Nhận email nhắc hạn mượn</label>
        </form>
        <p class="reader-profile__privacy">Thông tin này chỉ dùng cho việc quản lý tài khoản và liên hệ phục vụ thư viện.</p>
      </div>
    </div>
  </section>
</template>

<style scoped>
.reader-profile__heading { margin-bottom: 24px; }
.reader-profile__heading h1 { margin: 7px 0 4px; }
.reader-profile__heading > p:last-child { margin: 0; color: var(--muted); }
.reader-profile__folio { display: grid; grid-template-columns: minmax(235px, .72fr) minmax(0, 1.5fr); overflow: hidden; border: 1px solid var(--line); border-radius: 14px; }
.reader-profile__identity { position: relative; padding: 32px 28px; color: #f5f7fc; background: var(--navy-deep); }
.reader-profile__identity::after { position: absolute; top: 0; right: 0; width: 5px; height: 100%; background: var(--gold); content: ''; }
.reader-profile__seal, .reader-profile__photo { display: grid; place-items: center; width: 76px; height: 76px; margin-bottom: 13px; color: var(--navy-deep); background: #f6e9b9; border: 3px double #d4ae44; border-radius: 50%; font-size: 1.5rem; font-weight: 700; }
.reader-profile__photo { object-fit: cover; }
.reader-profile__photo-tools { display: flex; flex-wrap: wrap; align-items: center; gap: 7px 10px; margin: 0 0 24px; }
.reader-profile__photo-picker { position: relative; display: inline-flex; min-height: 30px; align-items: center; padding: 5px 9px; overflow: hidden; color: #f2e7c1; border: 1px solid #ffffff42; border-radius: 6px; cursor: pointer; font-size: .7rem; font-weight: 600; }
.reader-profile__photo-picker:focus-within { outline: 2px solid #f2e7c1; outline-offset: 2px; }
.reader-profile__photo-picker input { position: absolute; inset: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer; }
.reader-profile__photo-picker--busy { opacity: .65; cursor: wait; }
.reader-profile__photo-remove { min-height: 30px; padding: 4px 8px; color: #f5f7fc; background: transparent; border-color: #ffffff42; font-size: .7rem; }
.reader-profile__photo-tools small { flex-basis: 100%; color: #c5d0e7; font-size: .67rem; }
.reader-profile__photo-error, .reader-profile__photo-success { flex-basis: 100%; margin: 2px 0 0; font-size: .72rem; line-height: 1.45; }
.reader-profile__photo-error { color: #ffd3ce; }
.reader-profile__photo-success { color: #c7ebd5; }
.reader-profile__overline { color: #c5d0e7; font-size: .68rem; font-weight: 700; letter-spacing: .11em; text-transform: uppercase; }
.reader-profile__identity h2 { margin: 7px 0; color: #fff; font-size: 1.25rem; overflow-wrap: anywhere; }
.reader-profile__login-email { color: #d2daeb; font-size: .83rem; overflow-wrap: anywhere; }
.reader-profile__rule { width: 100%; height: 1px; margin: 24px 0; background: #ffffff2b; }
.reader-profile__roles { display: grid; gap: 8px; margin: 10px 0 22px; padding: 0; list-style: none; }
.reader-profile__roles li { width: fit-content; padding: 5px 9px; color: #f2e7c1; background: #ffffff12; border: 1px solid #ffffff24; border-radius: 999px; font-size: .73rem; }
.reader-profile__card { display: grid; gap: 6px; margin: 20px 0; padding: 13px; color: #f5f7fc; background: #ffffff12; border: 1px solid #ffffff24; border-radius: 10px; font-size: .75rem; }
.reader-profile__card strong { color: #f2e7c1; font-size: .9rem; letter-spacing: .06em; }
.reader-profile__card span:not(:first-child) { color: #d2daeb; }
.reader-profile__footnote { margin: 0; color: #c5d0e7; font-size: .73rem; line-height: 1.6; }
.reader-profile__form-wrap { padding: clamp(22px, 4vw, 40px); }
.reader-profile__form-heading { margin-bottom: 20px; }
.reader-profile__form-heading h2 { margin-bottom: 5px; }
.reader-profile__form-heading p { margin-bottom: 0; color: var(--muted); font-size: .83rem; }
.reader-profile form { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 17px; }
.reader-profile form label { min-width: 0; }
.reader-profile form label:nth-child(2) { grid-column: 1 / -1; }
.reader-profile form label small { color: var(--muted); font-size: .72rem; font-weight: 400; }
.reader-profile form .reader-profile__email-preference { display: flex; grid-column: 1 / -1; align-items: center; gap: 9px; font-weight: 500; }
.reader-profile__email-preference input { width: 17px; height: 17px; accent-color: var(--navy); }
.reader-profile form button { justify-self: start; min-width: 150px; margin-top: 2px; }
.reader-profile__privacy { margin: 22px 0 0; padding-top: 14px; color: var(--muted); border-top: 1px solid var(--line); font-size: .73rem; }
.reader-profile__success { padding: 11px 13px; color: #2f6451; background: #e8f5ed; border: 1px solid #c8e4d1; border-radius: 8px; font-size: .83rem; }
@media (max-width: 680px) { .reader-profile__folio { grid-template-columns: 1fr; } .reader-profile__identity { padding: 24px; } .reader-profile__seal, .reader-profile__photo { width: 64px; height: 64px; } }
@media (max-width: 480px) { .reader-profile form { grid-template-columns: 1fr; } .reader-profile form label:nth-child(2) { grid-column: auto; } }
</style>
