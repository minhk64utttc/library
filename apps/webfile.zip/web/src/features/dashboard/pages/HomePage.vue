<script setup lang="ts">
import { computed } from 'vue';
import { RouterLink } from 'vue-router';

import { NAV_ITEMS } from '@/app/navigation';
import { useSessionStore } from '@/features/auth/session.store';

const session = useSessionStore();
const moduleDescriptions: Record<string, string> = {
  '/catalog/records': 'Tạo bản ghi, xét duyệt và công bố tài liệu.',
  '/catalog/publishers': 'Quản lý thông tin nhà xuất bản.',
  '/holdings': 'Theo dõi bản sao, vị trí và mã xếp giá.',
  '/incidents': 'Ghi nhận, tra soát và quyết định xử lý sự cố tài liệu.',
  '/inventory': 'Quét mã cuốn, đối soát vị trí và tra soát bản sao chưa thấy.',
  '/circulation/loans': 'Ghi nhận mượn, trả và gia hạn tài liệu.',
  '/circulation/cards': 'Cấp, gia hạn và quản lý trạng thái thẻ bạn đọc.',
  '/circulation/reservations': 'Theo dõi hàng chờ và giữ sách.',
  '/circulation/fines': 'Xem và xử lý các khoản phạt.',
};
const availableModules = computed(() =>
  NAV_ITEMS.filter((item) => item.to !== '/' && (!item.permission || session.can(item.permission))),
);
</script>

<template>
  <section class="home">
    <div class="home__intro">
      <span class="eyebrow">Trường Đại học Giao thông Vận tải</span>
      <h1>Không gian làm việc của thư viện</h1>
      <p v-if="session.account">Xin chào {{ session.account.fullName }}. Chọn nghiệp vụ để bắt đầu.</p>
    </div>

    <div class="home__section-head">
      <h2>Nghiệp vụ của bạn</h2>
      <p>Các mục hiển thị theo quyền tài khoản.</p>
    </div>
    <div v-if="availableModules.length" class="home__modules">
      <RouterLink v-for="item in availableModules" :key="item.to" class="home__module" :to="item.to">
        <strong>{{ item.label }}</strong>
        <span>{{ moduleDescriptions[item.to] }}</span>
        <span class="home__module-arrow" aria-hidden="true">→</span>
      </RouterLink>
    </div>
    <p v-else class="empty-state">Tài khoản chưa có nghiệp vụ được phân quyền.</p>
  </section>
</template>
