<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { RouterLink } from 'vue-router';
import type { CatalogRecordDto, RecordStatus } from '@thu-vien/shared';

import { useSessionStore } from '@/features/auth/session.store';
import { ApiError } from '@/shared/api/client';
import * as catalogApi from '../api';
import { RECORD_STATUS_OPTIONS, statusLabel } from '../status';

const session = useSessionStore();

const records = ref<CatalogRecordDto[]>([]);
const total = ref(0);
const loading = ref(false);
const errorMessage = ref('');
const statusFilter = ref<RecordStatus | ''>('');
const pendingId = ref<string | null>(null);
const rejectingId = ref<string | null>(null);
const rejectReason = ref('');

const canWrite = computed(() => session.can('catalog:write'));
const canApprove = computed(() => session.can('catalog:approve'));

async function load(): Promise<void> {
  loading.value = true;
  errorMessage.value = '';
  try {
    const result = await catalogApi.listRecords({
      pageSize: 50,
      ...(statusFilter.value ? { status: statusFilter.value } : {}),
    });
    records.value = result.items;
    total.value = result.total;
  } catch {
    errorMessage.value = 'Không tải được danh sách bản ghi.';
  } finally {
    loading.value = false;
  }
}

async function run(id: string, action: () => Promise<unknown>): Promise<void> {
  pendingId.value = id;
  errorMessage.value = '';
  try {
    await action();
    await load();
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError ? `Thao tác thất bại (${error.status}).` : 'Thao tác thất bại.';
  } finally {
    pendingId.value = null;
  }
}

function onStatusChange(): void {
  void load();
}

function submitRecord(record: CatalogRecordDto): void {
  void run(record.id, () => catalogApi.submitRecord(record.id));
}

function approveRecord(record: CatalogRecordDto): void {
  void run(record.id, () => catalogApi.approveRecord(record.id));
}

function publishRecord(record: CatalogRecordDto): void {
  void run(record.id, () => catalogApi.publishRecord(record.id));
}

function startReject(record: CatalogRecordDto): void {
  rejectingId.value = record.id;
  rejectReason.value = '';
}

function cancelReject(): void {
  rejectingId.value = null;
  rejectReason.value = '';
}

function onRejectSubmit(): void {
  const id = rejectingId.value;
  const reason = rejectReason.value.trim();
  if (!id || !reason) {
    return;
  }
  void run(id, () => catalogApi.rejectRecord(id, reason)).then(() => {
    rejectingId.value = null;
    rejectReason.value = '';
  });
}

onMounted(() => {
  void load();
});
</script>

<template>
  <section class="records">
    <div class="records__head">
      <h1>Bản ghi biên mục</h1>
      <RouterLink v-if="canWrite" :to="{ name: 'catalog-record-new' }">Tạo bản ghi</RouterLink>
    </div>

    <label>
      Trạng thái
      <select v-model="statusFilter" @change="onStatusChange">
        <option value="">Tất cả</option>
        <option v-for="status in RECORD_STATUS_OPTIONS" :key="status" :value="status">
          {{ statusLabel(status) }}
        </option>
      </select>
    </label>

    <p v-if="errorMessage" role="alert">{{ errorMessage }}</p>
    <p v-if="loading">Đang tải…</p>
    <p v-else-if="records.length === 0" class="empty-state">Chưa có bản ghi nào. Tạo bản ghi để bắt đầu biên mục.</p>

    <table v-else>
      <caption>{{ total }} bản ghi</caption>
      <thead>
        <tr>
          <th scope="col">Nhan đề</th>
          <th scope="col">Tác giả</th>
          <th scope="col">Trạng thái</th>
          <th scope="col">Ấn bản</th>
          <th scope="col">Thao tác</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="record in records" :key="record.id">
          <td>{{ record.title }}</td>
          <td>{{ record.author ?? '' }}</td>
          <td><span class="status-badge" :data-state="record.status">{{ statusLabel(record.status) }}</span></td>
          <td>{{ record.editions.length }}</td>
          <td>
            <RouterLink
              v-if="canWrite && (record.status === 'draft' || record.status === 'withdrawn')"
              :to="{ name: 'catalog-record-edit', params: { id: record.id } }"
            >
              Sửa
            </RouterLink>
            <button
              v-if="canWrite && record.status === 'draft'"
              type="button"
              :disabled="pendingId === record.id"
              @click="submitRecord(record)"
            >
              Gửi duyệt
            </button>
            <button
              v-if="canApprove && record.status === 'pending'"
              type="button"
              :disabled="pendingId === record.id"
              @click="approveRecord(record)"
            >
              Duyệt
            </button>
            <button
              v-if="canApprove && record.status === 'pending'"
              type="button"
              :disabled="pendingId === record.id"
              @click="startReject(record)"
            >
              Từ chối
            </button>
            <button
              v-if="canApprove && record.status === 'approved'"
              type="button"
              :disabled="pendingId === record.id"
              @click="publishRecord(record)"
            >
              Công bố
            </button>
          </td>
        </tr>
      </tbody>
    </table>

    <form v-if="rejectingId" class="records__reject" @submit.prevent="onRejectSubmit">
      <label>
        Lý do từ chối
        <input v-model="rejectReason" type="text" required />
      </label>
      <button type="submit">Xác nhận từ chối</button>
      <button type="button" @click="cancelReject">Hủy</button>
    </form>
  </section>
</template>
