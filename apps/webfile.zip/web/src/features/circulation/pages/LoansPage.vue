<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue';
import type { BorrowerDto, CopyDto, LoanDto, LoanStatus } from '@thu-vien/shared';

import { useSessionStore } from '@/features/auth/session.store';
import { ApiError } from '@/shared/api/client';
import * as circApi from '../api';

const session = useSessionStore();
const canManage = computed(() => session.can('circulation:manage'));

const loans = ref<LoanDto[]>([]);
const copies = ref<CopyDto[]>([]);
const borrowers = ref<BorrowerDto[]>([]);
const loading = ref(false);
const errorMessage = ref('');
const statusFilter = ref<LoanStatus | ''>('');
const overdueOnly = ref(false);
const pendingId = ref<string | null>(null);
const submitting = ref(false);

const borrowForm = reactive({ borrowerId: '', copyId: '', search: '' });

const STATUS_LABELS: Record<string, string> = {
  active: 'Đang mượn',
  returned: 'Đã trả',
  lost: 'Mất',
};

async function load(): Promise<void> {
  loading.value = true;
  errorMessage.value = '';
  try {
    const [loanResult, copyResult] = await Promise.all([
      circApi.listLoans({
        pageSize: 100,
        ...(statusFilter.value ? { status: statusFilter.value } : {}),
        ...(overdueOnly.value ? { overdue: true } : {}),
      }),
      canManage.value ? circApi.listAvailableCopies() : Promise.resolve({ items: [], total: 0, page: 1, pageSize: 0 }),
    ]);
    loans.value = loanResult.items;
    copies.value = copyResult.items;
    if (canManage.value) {
      borrowers.value = await circApi.searchBorrowers('');
    }
  } catch {
    errorMessage.value = 'Không tải được dữ liệu lưu thông.';
  } finally {
    loading.value = false;
  }
}

async function onSearchBorrowers(): Promise<void> {
  try {
    borrowers.value = await circApi.searchBorrowers(borrowForm.search.trim());
    borrowForm.borrowerId = borrowers.value.length > 0 ? (borrowers.value[0]?.id ?? '') : '';
  } catch {
    errorMessage.value = 'Không tìm được bạn đọc.';
  }
}

async function run(id: string, action: () => Promise<unknown>): Promise<void> {
  pendingId.value = id;
  errorMessage.value = '';
  try {
    await action();
    await load();
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError ? `Thao tác thất bại (${error.status}).` : 'Thao tác thất bại.';
  } finally {
    pendingId.value = null;
  }
}

function onReturn(loan: LoanDto): void {
  void run(loan.id, () => circApi.returnLoan(loan.id));
}

function onRenew(loan: LoanDto): void {
  void run(loan.id, () => circApi.renewLoan(loan.id));
}

async function onBorrow(): Promise<void> {
  if (!borrowForm.borrowerId || !borrowForm.copyId) {
    errorMessage.value = 'Chọn bạn đọc và bản sao trước khi cho mượn.';
    return;
  }
  submitting.value = true;
  errorMessage.value = '';
  try {
    await circApi.borrow({ borrowerId: borrowForm.borrowerId, copyId: borrowForm.copyId });
    borrowForm.copyId = '';
    await load();
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError ? `Không cho mượn được (${error.status}).` : 'Không cho mượn được.';
  } finally {
    submitting.value = false;
  }
}

function formatDate(value: string | null): string {
  return value ? new Date(value).toLocaleDateString('vi-VN') : '';
}

onMounted(() => {
  void load();
});
</script>

<template>
  <section class="loans">
    <h1>Quầy mượn trả</h1>

    <p v-if="errorMessage" role="alert">{{ errorMessage }}</p>

    <fieldset v-if="canManage">
      <legend>Cho mượn</legend>
      <form class="loans__inline" @submit.prevent="onSearchBorrowers">
        <label>
          Tìm bạn đọc (tên/email)
          <input v-model="borrowForm.search" type="text" />
        </label>
        <button type="submit">Tìm</button>
      </form>
      <form class="loans__inline" @submit.prevent="onBorrow">
        <label>
          Bạn đọc
          <select v-model="borrowForm.borrowerId" required>
            <option value="">—</option>
            <option v-for="borrower in borrowers" :key="borrower.id" :value="borrower.id">
              {{ borrower.fullName ?? borrower.email }}
            </option>
          </select>
        </label>
        <label>
          Bản sao (sẵn sàng)
          <select v-model="borrowForm.copyId" required>
            <option value="">—</option>
            <option v-for="copy in copies" :key="copy.id" :value="copy.id">
              {{ copy.code }} — {{ copy.workTitle ?? '' }}
            </option>
          </select>
        </label>
        <button type="submit" :disabled="submitting">Cho mượn</button>
      </form>
    </fieldset>

    <div class="loans__filters">
      <label>
        Trạng thái
        <select v-model="statusFilter" @change="load">
          <option value="">Tất cả</option>
          <option value="active">Đang mượn</option>
          <option value="returned">Đã trả</option>
          <option value="lost">Mất</option>
        </select>
      </label>
      <label>
        <input v-model="overdueOnly" type="checkbox" @change="load" />
        Chỉ quá hạn
      </label>
    </div>

    <p v-if="loading">Đang tải…</p>
    <p v-else-if="loans.length === 0" class="empty-state">Chưa có khoản mượn nào trong bộ lọc hiện tại.</p>

    <table v-else>
      <thead>
        <tr>
          <th scope="col">Mã cuốn</th>
          <th scope="col">Tác phẩm</th>
          <th scope="col">Bạn đọc</th>
          <th scope="col">Hạn trả</th>
          <th scope="col">Trạng thái</th>
          <th scope="col">Quá hạn</th>
          <th scope="col">Phạt</th>
          <th scope="col">Thao tác</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="loan in loans" :key="loan.id">
          <td>{{ loan.copyCode }}</td>
          <td>{{ loan.workTitle ?? '' }}</td>
          <td>{{ loan.borrowerName ?? '' }}</td>
          <td>{{ formatDate(loan.dueAt) }}</td>
          <td><span class="status-badge" :data-state="loan.status">{{ STATUS_LABELS[loan.status] ?? loan.status }}</span></td>
          <td>{{ loan.overdueDays > 0 ? loan.overdueDays + ' ngày' : '' }}</td>
          <td>{{ loan.fineAmount !== null ? loan.fineAmount.toLocaleString('vi-VN') + ' đ' : '' }}</td>
          <td>
            <template v-if="canManage && loan.status === 'active'">
              <button type="button" :disabled="pendingId === loan.id" @click="onReturn(loan)">
                Trả
              </button>
              <button type="button" :disabled="pendingId === loan.id" @click="onRenew(loan)">
                Gia hạn
              </button>
            </template>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>
