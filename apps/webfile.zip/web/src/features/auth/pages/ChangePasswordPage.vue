<script setup lang="ts">
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';

import { ApiError } from '@/shared/api/client';
import { useSessionStore } from '../session.store';

const session = useSessionStore();
const router = useRouter();

const form = reactive({ currentPassword: '', newPassword: '', confirmPassword: '' });
const errorMessage = ref('');
const submitting = ref(false);

async function onSubmit(): Promise<void> {
  errorMessage.value = '';

  if (form.newPassword !== form.confirmPassword) {
    errorMessage.value = 'Mật khẩu mới nhập lại không khớp.';
    return;
  }

  submitting.value = true;
  try {
    await session.changePassword({
      currentPassword: form.currentPassword,
      newPassword: form.newPassword,
    });
    await router.replace('/');
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError && error.status === 400
        ? 'Mật khẩu hiện tại không đúng.'
        : 'Không đổi được mật khẩu. Vui lòng thử lại.';
  } finally {
    submitting.value = false;
  }
}

async function onLogout(): Promise<void> {
  await session.logout();
  await router.replace({ name: 'login' });
}
</script>

<template>
  <section class="change-password">
    <img src="/img/utc-logo.png" alt="Trường Đại học Giao thông Vận tải" width="121" height="76" />
    <span class="eyebrow">Thư viện · Bảo vệ tài khoản</span>
    <h1>Đổi mật khẩu</h1>
    <p>Bạn cần đổi mật khẩu trước khi tiếp tục.</p>

    <form @submit.prevent="onSubmit">
      <label>
        Mật khẩu hiện tại
        <input v-model="form.currentPassword" type="password" autocomplete="current-password" required />
      </label>

      <label>
        Mật khẩu mới
        <input v-model="form.newPassword" type="password" autocomplete="new-password" minlength="8" required />
      </label>

      <label>
        Nhập lại mật khẩu mới
        <input v-model="form.confirmPassword" type="password" autocomplete="new-password" minlength="8" required />
      </label>

      <p v-if="errorMessage" role="alert">{{ errorMessage }}</p>

      <button type="submit" :disabled="submitting">
        {{ submitting ? 'Đang lưu…' : 'Đổi mật khẩu' }}
      </button>
    </form>

    <footer class="change-password__footer">
      <span v-if="session.account">{{ session.account.email }}</span>
      <button type="button" class="link-button" @click="onLogout">Đăng xuất</button>
    </footer>
  </section>
</template>
