<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue';
import { ROLES, type AccountDto, type Role } from '@thu-vien/shared';

import { useSessionStore } from '@/features/auth/session.store';
import { ApiError } from '@/shared/api/client';
import * as accountsApi from '../api';

const session = useSessionStore();
const canManage = computed(() => session.can('accounts:manage'));

const accounts = ref<AccountDto[]>([]);
const loading = ref(false);
const errorMessage = ref('');
const noticeMessage = ref('');
const filters = reactive({ q: '', status: '' as '' | 'active' | 'disabled', role: '' as '' | Role });
const pendingId = ref<string | null>(null);
const submitting = ref(false);

const createForm = reactive({
  email: '',
  fullName: '',
  password: '',
  roles: ['reader'] as Role[],
  readerGroup: 'student' as AccountDto['readerGroup'],
  status: 'active' as 'active' | 'disabled',
  mustChangePassword: true,
});

const resetFor = ref<string | null>(null);
const resetForm = reactive({ password: '' });

const editingRolesId = ref<string | null>(null);
const editRoles = ref<Role[]>([]);

const STATUS_LABELS: Record<string, string> = { active: 'Hoạt động', disabled: 'Tắt' };
const ROLE_LABELS: Record<Role, string> = {
  reader: 'Bạn đọc',
  circulation: 'Mượn trả',
  cataloging: 'Biên mục',
  inventory: 'Kho',
  digital: 'Học liệu số',
  manager: 'Quản lý',
  admin: 'Quản trị',
};

const READER_GROUP_LABELS: Record<AccountDto['readerGroup'], string> = {
  student: 'Sinh viên', lecturer: 'Giảng viên', staff: 'Nhân viên', other: 'Khác',
};

async function load(): Promise<void> {
  loading.value = true;
  errorMessage.value = '';
  try {
    const result = await accountsApi.listAccounts({
      pageSize: 100,
      ...(filters.q ? { q: filters.q } : {}),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.role ? { role: filters.role } : {}),
    });
    accounts.value = result.items;
  } catch {
    errorMessage.value = 'Không tải được danh sách tài khoản.';
  } finally {
    loading.value = false;
  }
}

async function onCreate(): Promise<void> {
  if (createForm.roles.length === 0) {
    errorMessage.value = 'Chọn ít nhất một vai trò.';
    return;
  }
  submitting.value = true;
  errorMessage.value = '';
  noticeMessage.value = '';
  try {
    await accountsApi.createAccount({
      email: createForm.email.trim(),
      fullName: createForm.fullName.trim(),
      password: createForm.password,
      roles: createForm.roles,
      readerGroup: createForm.readerGroup,
      status: createForm.status,
      mustChangePassword: createForm.mustChangePassword,
    });
    createForm.email = '';
    createForm.fullName = '';
    createForm.password = '';
    createForm.roles = ['reader'];
    createForm.readerGroup = 'student';
    createForm.status = 'active';
    createForm.mustChangePassword = true;
    await load();
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError && error.status === 409
        ? 'Email đã tồn tại.'
        : 'Không tạo được tài khoản.';
  } finally {
    submitting.value = false;
  }
}

async function toggleStatus(account: AccountDto): Promise<void> {
  pendingId.value = account.id;
  errorMessage.value = '';
  noticeMessage.value = '';
  try {
    const updated = await accountsApi.updateAccount(account.id, {
      status: account.status === 'active' ? 'disabled' : 'active',
    });
    noticeMessage.value =
      updated.status === 'disabled'
        ? `Đã tắt ${updated.email}; mọi phiên bị thu hồi.`
        : `Đã bật ${updated.email}.`;
    await load();
  } catch {
    errorMessage.value = 'Không đổi được trạng thái tài khoản.';
  } finally {
    pendingId.value = null;
  }
}

async function changeReaderGroup(account: AccountDto, event: Event): Promise<void> {
  const readerGroup = (event.target as HTMLSelectElement).value as AccountDto['readerGroup'];
  pendingId.value = account.id;
  errorMessage.value = '';
  try {
    const updated = await accountsApi.updateAccount(account.id, { readerGroup });
    accounts.value = accounts.value.map((item) => item.id === updated.id ? updated : item);
    noticeMessage.value = `Đã cập nhật nhóm bạn đọc cho ${updated.email}.`;
  } catch {
    errorMessage.value = 'Không cập nhật được nhóm bạn đọc.';
  } finally {
    pendingId.value = null;
  }
}

function startReset(account: AccountDto): void {
  resetFor.value = account.id;
  resetForm.password = '';
}

function cancelReset(): void {
  resetFor.value = null;
  resetForm.password = '';
}

async function onReset(account: AccountDto): Promise<void> {
  pendingId.value = account.id;
  errorMessage.value = '';
  noticeMessage.value = '';
  try {
    await accountsApi.resetAccountPassword(account.id, { password: resetForm.password });
    noticeMessage.value = `Đã đặt lại mật khẩu ${account.email}; tài khoản sẽ phải đổi mật khẩu lúc đăng nhập.`;
    resetFor.value = null;
    resetForm.password = '';
    await load();
  } catch {
    errorMessage.value = 'Không đặt lại được mật khẩu.';
  } finally {
    pendingId.value = null;
  }
}

function startEditRoles(account: AccountDto): void {
  editingRolesId.value = account.id;
  editRoles.value = [...account.roles];
}

function toggleRole(role: Role): void {
  const index = editRoles.value.indexOf(role);
  if (index >= 0) {
    editRoles.value.splice(index, 1);
  } else {
    editRoles.value.push(role);
  }
}

async function onSaveRoles(account: AccountDto): Promise<void> {
  if (editRoles.value.length === 0) {
    errorMessage.value = 'Chọn ít nhất một vai trò.';
    return;
  }
  pendingId.value = account.id;
  errorMessage.value = '';
  try {
    await accountsApi.updateAccount(account.id, { roles: editRoles.value });
    editingRolesId.value = null;
    await load();
  } catch {
    errorMessage.value = 'Không lưu được vai trò.';
  } finally {
    pendingId.value = null;
  }
}

onMounted(() => {
  void load();
});
</script>

<template>
  <section class="accounts">
    <h1>Tài khoản</h1>

    <p v-if="errorMessage" role="alert">{{ errorMessage }}</p>
    <p v-if="noticeMessage">{{ noticeMessage }}</p>

    <fieldset v-if="canManage">
      <legend>Thêm tài khoản</legend>
      <form class="accounts__form" @submit.prevent="onCreate">
        <label>
          Email
          <input v-model="createForm.email" type="email" required maxlength="200" />
        </label>
        <label>
          Họ tên
          <input v-model="createForm.fullName" type="text" required maxlength="200" />
        </label>
        <label>
          Mật khẩu
          <input v-model="createForm.password" type="password" required minlength="8" />
        </label>
        <fieldset class="accounts__roles">
          <legend>Vai trò</legend>
          <label v-for="role in ROLES" :key="role">
            <input
              type="checkbox"
              :checked="createForm.roles.includes(role)"
              @change="toggleRole(role)"
            />
            {{ ROLE_LABELS[role] }}
          </label>
        </fieldset>
        <label>Reader group
          <select v-model="createForm.readerGroup">
            <option v-for="(label, group) in READER_GROUP_LABELS" :key="group" :value="group">{{ label }}</option>
          </select>
        </label>
        <label>
          Trạng thái
          <select v-model="createForm.status">
            <option value="active">Hoạt động</option>
            <option value="disabled">Tắt</option>
          </select>
        </label>
        <label>
          <input v-model="createForm.mustChangePassword" type="checkbox" />
          Bắt buộc đổi mật khẩu lần đầu
        </label>
        <button type="submit" :disabled="submitting">Thêm</button>
      </form>
    </fieldset>

    <div class="accounts__filters">
      <label>
        Tìm
        <input v-model="filters.q" type="text" @change="load" />
      </label>
      <label>
        Trạng thái
        <select v-model="filters.status" @change="load">
          <option value="">Tất cả</option>
          <option value="active">Hoạt động</option>
          <option value="disabled">Tắt</option>
        </select>
      </label>
      <label>
        Vai trò
        <select v-model="filters.role" @change="load">
          <option value="">Tất cả</option>
          <option v-for="role in ROLES" :key="role" :value="role">{{ ROLE_LABELS[role] }}</option>
        </select>
      </label>
    </div>

    <p v-if="loading">Đang tải…</p>
    <p v-else-if="accounts.length === 0">Chưa có tài khoản nào.</p>

    <table v-else>
      <thead>
        <tr>
          <th scope="col">Email</th>
          <th scope="col">Họ tên</th>
          <th scope="col">Vai trò</th>
          <th scope="col">Trạng thái</th>
          <th scope="col">Thao tác</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="account in accounts" :key="account.id">
          <td>{{ account.email }}</td>
          <td>
            {{ account.fullName }}
            <label v-if="canManage" class="accounts__reader-group">Reader group
              <select :value="account.readerGroup" :disabled="pendingId === account.id" @change="changeReaderGroup(account, $event)">
                <option v-for="(label, group) in READER_GROUP_LABELS" :key="group" :value="group">{{ label }}</option>
              </select>
            </label>
          </td>
          <td>
            <template v-if="editingRolesId === account.id">
              <label v-for="role in ROLES" :key="role" class="accounts__rolecheck">
                <input
                  type="checkbox"
                  :checked="editRoles.includes(role)"
                  @change="toggleRole(role)"
                />
                {{ ROLE_LABELS[role] }}
              </label>
              <button type="button" :disabled="pendingId === account.id" @click="onSaveRoles(account)">Lưu</button>
              <button type="button" @click="editingRolesId = null">Hủy</button>
            </template>
            <template v-else>
              {{ account.roles.map((role) => ROLE_LABELS[role]).join(', ') }}
              <button v-if="canManage" type="button" @click="startEditRoles(account)">Sửa</button>
            </template>
          </td>
          <td>{{ STATUS_LABELS[account.status] ?? account.status }}{{ account.mustChangePassword ? ' · phải đổi MK' : '' }}</td>
          <td>
            <template v-if="canManage">
              <button
                type="button"
                :disabled="pendingId === account.id"
                @click="toggleStatus(account)"
              >
                {{ account.status === 'active' ? 'Tắt' : 'Bật' }}
              </button>
              <button type="button" @click="startReset(account)">Đặt lại mật khẩu</button>
              <template v-if="resetFor === account.id">
                <input v-model="resetForm.password" type="password" placeholder="Mật khẩu mới" minlength="8" />
                <button type="button" :disabled="pendingId === account.id" @click="onReset(account)">Lưu</button>
                <button type="button" @click="cancelReset">Hủy</button>
              </template>
            </template>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>
