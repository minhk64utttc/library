import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router';

import { accountsRoutes } from '@/features/accounts/routes';
import { authRoutes } from '@/features/auth/routes';
import { useSessionStore } from '@/features/auth/session.store';
import { catalogRoutes } from '@/features/catalog/routes';
import { circulationRoutes } from '@/features/circulation/routes';
import { holdingsRoutes } from '@/features/holdings/routes';
import { incidentRoutes } from '@/features/incidents/routes';
import { inventoryRoutes } from '@/features/inventory/routes';
import { digitalRoutes } from '@/features/digital/routes';
import { managementRoutes } from '@/features/management/routes';
import { publicRoutes } from '@/features/public/routes';
import { profileRoutes } from '@/features/profile/routes';

const routes: RouteRecordRaw[] = [
  ...publicRoutes,
  ...profileRoutes,
  ...authRoutes,
  {
    path: '/',
    component: () => import('@/app/layouts/StaffLayout.vue'),
    children: [
      {
        path: '',
        name: 'home',
        component: () => import('@/features/dashboard/pages/HomePage.vue'),
      },
      ...catalogRoutes,
      ...holdingsRoutes,
      ...incidentRoutes,
      ...inventoryRoutes,
      ...digitalRoutes,
      ...managementRoutes,
      ...circulationRoutes,
      ...accountsRoutes,
    ],
  },
];

export const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach(async (to) => {
  const session = useSessionStore();

  if (!session.initialized) {
    await session.load();
  }

  const isPublic = to.meta.public === true;

  if (!isPublic && !session.isAuthenticated) {
    return { name: 'login', query: { redirect: to.fullPath } };
  }

  if (session.isAuthenticated && session.mustChangePassword && to.name !== 'change-password') {
    return { name: 'change-password' };
  }

  if (to.name === 'login' && session.isAuthenticated) {
    return { name: 'home' };
  }

  return true;
});
